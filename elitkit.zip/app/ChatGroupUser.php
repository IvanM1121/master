<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatGroupUser extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'chat_group_users';
	
	
}